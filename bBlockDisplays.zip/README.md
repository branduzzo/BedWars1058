## bBlockDisplays — Fork of BlockDisplayCreator by General_Breddok

> **Fork** maintained by **Branduzzo** — original by **General_Breddok**. Folia & Horizon compatible and optimized.

[![bStats](https://img.shields.io/bstats/servers/33676?label=bStats%20Servers)](https://bstats.org/plugin/bukkit/bBlockDisplays/33676)

## bBlockDisplays
[![](https://img.shields.io/badge/Spigot-F7FF00?logo=spigotmc&logoSize=auto)](https://www.spigotmc.org/resources/blockdisplaycreator.114877/)
![Spigot Download Size](https://img.shields.io/spiget/download-size/114877?style=flat-square)
![Spigot Downloads](https://img.shields.io/spiget/downloads/114877?label=Spigot%20Downloads&style=flat-square)

bBlockDisplays is a versatile plugin designed to work with [bdengine](https://block-display.com/), allowing you to create highly customizable custom blocks for decorating Minecraft server.

# Features of bBlockDisplays

- 🧱 **Custom blocks** with fully configurable display and easy import from **BdEngine**
- 🌍 **Support for all Minecraft versions starting from 1.19.4** — stable and future-proof
- ⚡ **Asynchronous block loading** for smooth server performance
- 🔄 **360° rotation** and placement on horizontal sides — full orientation control
- 🛠️ **Configurable count of block sides**
- 🌈 **Gradient support and PlaceholderAPI integration** — dynamic and beautiful effects
- 🛡️ **Integration with WorldGuard and SuperiorSkyblock2**: custom flags and permissions for advanced protection
- 🎭 **Customizable head-textured items** — perfect for decorative or unique blocks
- 📝 **Custom placeholders** for blocks and their entities
- 🎯 **Hitboxes of any size** with commands triggered on click
- 🚧🟪 **Collisions** to make blocks solid
- 🎵 **Fully customizable block sounds**
- 🔑 **Block-specific permissions** — fine-tuned access control
- 💬 **Fully configurable messages**
- 🎁 **Multiple drop and placement modes**
- ⛏️ **Commands on block placement and breaking** — automate interactions
- 🖱️ **Quick select with mouse wheel** *(available in Minecraft 1.21.4+)*
- 🧭 **Convenient commands** for giving, placing, breaking, and editing blocks with many parameters
- 📦 **Datapack compatibility**: commands can be executed from command blocks, and entities receive their own Scoreboard tags
- 🔧 **Special parameters for version compatibility** — consistent behavior across Minecraft versions
- ⚙️ **Horizon support** via [CraftCanvasMC/Horizon](https://github.com/CraftCanvasMC/Horizon) mixin wrapper
- 📊 **bStats** `33676` with minimal resource usage and Folia/Horizon aware scheduler
