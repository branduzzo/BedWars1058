package it.branduzzo.bBlockDisplays.web.player;

import it.branduzzo.bBlockDisplays.annotation.EmptyCollection;

import java.util.List;

public interface MojangSession {
    String getId();

    String getName();

    @EmptyCollection
    List<MojangSessionProperty> getProperties();

    @EmptyCollection
    List<String> getProfileActions();
}
