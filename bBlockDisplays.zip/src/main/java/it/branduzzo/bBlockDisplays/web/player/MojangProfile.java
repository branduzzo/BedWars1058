package it.branduzzo.bBlockDisplays.web.player;

public interface MojangProfile {
    String getId();

    String getName();
}
