package it.branduzzo.bBlockDisplays.commandparser.argument;

import it.branduzzo.bBlockDisplays.commandparser.CommandLine;

public interface CommandArgument {
    CommandLine getCommandLine();

    @Override
    String toString();
}
