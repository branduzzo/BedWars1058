package it.branduzzo.bBlockDisplays.commandparser;

import it.branduzzo.bBlockDisplays.placeholder.universal.UniversalPlaceholder;
import org.bukkit.command.CommandSender;

public interface CommandContainer {
    void execute(CommandSender sender, UniversalPlaceholder<?>... placeholders);
}
