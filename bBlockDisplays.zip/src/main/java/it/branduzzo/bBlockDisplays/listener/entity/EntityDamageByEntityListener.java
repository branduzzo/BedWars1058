package it.branduzzo.bBlockDisplays.listener.entity;

import it.branduzzo.bBlockDisplays.BlockDisplayCreator;
import it.branduzzo.bBlockDisplays.common.BDCDependentPluginsManager;
import it.branduzzo.bBlockDisplays.custom.block.CustomBlock;
import it.branduzzo.bBlockDisplays.custom.block.CustomBlockKey;
import it.branduzzo.bBlockDisplays.custom.block.CustomBlockPermissions;
import it.branduzzo.bBlockDisplays.custom.block.CustomBlockService;
import it.branduzzo.bBlockDisplays.custom.block.option.CustomBlockBreakOption;
import it.branduzzo.bBlockDisplays.custom.block.option.CustomBlockOption;
import it.branduzzo.bBlockDisplays.file.config.value.BooleanConfigValue;
import it.branduzzo.bBlockDisplays.file.config.value.StringMessagesValue;
import it.branduzzo.bBlockDisplays.permission.DefaultPermissions;
import it.branduzzo.bBlockDisplays.service.ServiceManager;
import it.branduzzo.bBlockDisplays.util.ChatUtil;
import it.branduzzo.bBlockDisplays.world.guard.WGRegionAccessChecker;
import it.branduzzo.bBlockDisplays.world.guard.WGRegionFlags;
import it.branduzzo.bBlockDisplays.world.skyblock.superior.SSBIslandAccessChecker;
import it.branduzzo.bBlockDisplays.world.skyblock.superior.SSBIslandPrivileges;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.entity.Shulker;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;


public class EntityDamageByEntityListener implements Listener {

    private final ServiceManager<String, CustomBlockService> serviceManager;

    public EntityDamageByEntityListener(ServiceManager<String, CustomBlockService> serviceManager) {
        this.serviceManager = serviceManager;
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player))
            return;

        if (player.getGameMode() == GameMode.ADVENTURE)
            return;

        Entity entity = event.getEntity();

        if (!(entity instanceof Interaction) && !(entity instanceof Shulker))
            return;

        String blockName = CustomBlockKey.holder(entity).getName();

        if (blockName == null)
            return;

        event.setCancelled(true);

        if (!BooleanConfigValue.BLOCKS_DESTRUCTION) {
            if (!player.hasPermission(DefaultPermissions.BDC.CustomBlock.BLOCKS_DESTRUCTION)) {
                ChatUtil.sendMessage(player, StringMessagesValue.PERMISSION_DENIED_BREAK);
                return;
            }
        }

        CustomBlockService customBlockService = CustomBlockService.getService(serviceManager, entity);

        CustomBlock customBlock = customBlockService.getCustomBlock(entity);

        if (customBlock == null) {
            ChatUtil.sendMessage(player, StringMessagesValue.CUSTOM_BLOCK_NOT_FOUND.replace("%customblock_name%", blockName));
            return;
        }

        if (!checkAccess(player, customBlock)) {
            return;
        }

        CustomBlockOption[] options = new CustomBlockOption[5];

        if (!(player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR)) {
            options[0] = CustomBlockBreakOption.DROP_ITEM;
        }

        try {
            customBlockService.breakBlock(customBlock, player, options);
        } catch (IllegalArgumentException ignore) {
        }
    }

    private static boolean checkAccess(Player player, CustomBlock customBlock) {
        BDCDependentPluginsManager dependentPluginManager = BlockDisplayCreator.getInstance().getDependentPluginsManager();
        Location customBlockLocation = customBlock.getLocation();

        if (dependentPluginManager.isWorldGuardAvailable()) {
            if (!WGRegionAccessChecker.checkRegionAccess(customBlockLocation, WGRegionFlags.BREAK_CB, player)) {
                ChatUtil.sendMessage(player, StringMessagesValue.REGION_DENIED_BREAK);
                return false;
            }
        }

        if (dependentPluginManager.isSuperiorSkyblockAvailable()) {
            if (!SSBIslandAccessChecker.checkIslandAccess(customBlockLocation, SSBIslandPrivileges.BREAK_CB, player)) {
                ChatUtil.sendMessage(player, StringMessagesValue.ISLAND_DENIED_BREAK);
                return false;
            }
        }

        CustomBlockPermissions permissions = customBlock.getPermissions();

        if (permissions != null) {
            if (!permissions.hasPermissions(player, CustomBlockPermissions.Type.BREAK)) {
                ChatUtil.sendMessage(player, StringMessagesValue.PERMISSION_DENIED_BREAK);
                return false;
            }
        }
        return true;
    }
}
