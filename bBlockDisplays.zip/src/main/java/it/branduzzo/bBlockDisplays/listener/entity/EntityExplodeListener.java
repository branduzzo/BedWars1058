package it.branduzzo.bBlockDisplays.listener.entity;

import com.jeff_media.customblockdata.CustomBlockData;
import it.branduzzo.bBlockDisplays.BlockDisplayCreator;
import it.branduzzo.bBlockDisplays.custom.block.CustomBlockKey;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;

public class EntityExplodeListener implements Listener {

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent event) {
        event.blockList().removeIf(block -> {
            CustomBlockData customBlockData = new CustomBlockData(block, BlockDisplayCreator.getInstance());

            return customBlockData.has(CustomBlockKey.NAME);
        });
    }
}
