package it.branduzzo.bBlockDisplays.nbt.entity.display;

import it.branduzzo.bBlockDisplays.entity.display.DisplayCharacteristics;
import it.branduzzo.bBlockDisplays.nbt.entity.NbtEntity;

public interface NbtDisplay extends NbtEntity, DisplayCharacteristics {
}
