package it.branduzzo.bBlockDisplays.command.capi;

import com.jeff_media.customblockdata.CustomBlockData;
import dev.jorel.commandapi.CommandAPI;
import dev.jorel.commandapi.CommandTree;
import dev.jorel.commandapi.Tooltip;
import dev.jorel.commandapi.arguments.*;
import dev.jorel.commandapi.executors.CommandArguments;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import it.branduzzo.bBlockDisplays.BlockDisplayCreator;
import it.branduzzo.bBlockDisplays.command.capi.tooltip.AbstractCustomBlockTooltip;
import it.branduzzo.bBlockDisplays.command.capi.tooltip.StringTooltip;
import it.branduzzo.bBlockDisplays.commandparser.CommandLine;
import it.branduzzo.bBlockDisplays.commandparser.MCCommandLine;
import it.branduzzo.bBlockDisplays.common.ColorConverter;
import it.branduzzo.bBlockDisplays.custom.*;
import it.branduzzo.bBlockDisplays.custom.block.*;
import it.branduzzo.bBlockDisplays.custom.block.option.CustomBlockBreakOption;
import it.branduzzo.bBlockDisplays.custom.block.option.CustomBlockPlaceOption;
import it.branduzzo.bBlockDisplays.data.manager.PersistentDataTypes;
import it.branduzzo.bBlockDisplays.data.manager.TypeTokens;
import it.branduzzo.bBlockDisplays.data.persistent.PersistentData;
import it.branduzzo.bBlockDisplays.entity.GroupSummoner;
import it.branduzzo.bBlockDisplays.file.config.loader.CustomBlockConfigurationFile;
import it.branduzzo.bBlockDisplays.file.config.value.StringMessagesValue;
import it.branduzzo.bBlockDisplays.permission.DefaultPermissions;
import it.branduzzo.bBlockDisplays.placeholder.universal.LocationPlaceholder;
import it.branduzzo.bBlockDisplays.placeholder.universal.PlayerSkinBase64Placeholder;
import it.branduzzo.bBlockDisplays.util.ChatUtil;
import it.branduzzo.bBlockDisplays.util.CommandUtil;
import it.branduzzo.bBlockDisplays.util.ItemUtil;
import it.branduzzo.bBlockDisplays.util.NumberUtil;
import it.branduzzo.bBlockDisplays.version.VersionCompat;
import it.branduzzo.bBlockDisplays.util.FoliaScheduler;
import it.branduzzo.bBlockDisplays.web.exception.BDEngineModelNotFoundException;
import it.branduzzo.bBlockDisplays.web.exception.InvalidResponseException;
import it.branduzzo.bBlockDisplays.web.serverapi.ServerApiBlockFactory;
import it.branduzzo.bBlockDisplays.web.serverapi.ServerApiFetcher;
import it.branduzzo.bBlockDisplays.world.WorldSelection;
import org.bukkit.*;
import it.branduzzo.bBlockDisplays.util.FoliaScheduler;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.permissions.Permission;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * Manages the registration and execution of BlockDisplayCreator commands using the CommandAPI.
 * <p>
 * This class sets up the command structure, permissions, and execution logic for various
 * BlockDisplayCreator commands, including custom block management, configuration reloading,
 * and data erasure.
 */
@FieldDefaults(level = AccessLevel.PRIVATE)
public class BlockDisplayCreatorCAPICommand {
    final BlockDisplayCreator plugin;
    @Getter
    List<AbstractCustomBlockTooltip> abstractCustomBlockTooltips = new ArrayList<>();
    final Map<String, List<String>> interactionSuggestions = new HashMap<>();
    final Map<String, List<String>> collisionSuggestions = new HashMap<>();

    public BlockDisplayCreatorCAPICommand(BlockDisplayCreator plugin) {
        this.plugin = plugin;
    }

    /**
     * Registers the BlockDisplayCreator commands with the CommandAPI.
     * <p>
     * This method defines the command structure, permissions, and execution logic
     * for various commands such as reloading configurations, giving custom blocks,
     * placing and breaking custom blocks, and erasing custom block data.
     * </p>
     */
    public void register() {
        new CommandTree("blockdisplaycreator")
                .withAliases("bdc")
                .withRequirement(sender ->
                        sender.hasPermission(DefaultPermissions.BDC.Command.RELOAD)
                                || sender.hasPermission(DefaultPermissions.BDC.Command.ERASE_CB_DATA)
                                || sender.hasPermission(DefaultPermissions.BDC.Command.GIVE_CB)
                                || sender.hasPermission(DefaultPermissions.BDC.Command.PLACE_CB)
                                || sender.hasPermission(DefaultPermissions.BDC.Command.BREAK_CB)
                                || sender.hasPermission(DefaultPermissions.BDC.Command.EDITFILE_CB)
                                || sender.hasPermission(DefaultPermissions.BDC.Command.CREATE_CB))


                .withShortDescription("Basic BlockDisplayCreator commands")
                .withFullDescription("BlockDisplayCreator commands for managing custom blocks and their configurations.")
                .withUsage(
                        "/bdc custom-block {give|editfile|place|break} <block> ...",
                        "/bdc reload [block]",
                        "/bdc erasecbdata <position1> <position2>",
                        "/bdc create <id>",
                        "/bdc spawn <id>"
                )
                .then(
                        new LiteralArgument("reload")
                                .withPermission(DefaultPermissions.BDC.Command.RELOAD)
                                .then(
                                        new TextArgument("block")
                                                .replaceSuggestions(getCustomBlockSuggestions())
                                                .setOptional(true)
                                                .executes((sender, args) -> {
                                                    String blockName = (String) args.get("block");

                                                    if (blockName != null) {
                                                        CustomBlockStorage storage = this.plugin.getCustomBlockService().getStorage();

                                                        if (!storage.containsAbstractCustomBlock(blockName)) {
                                                            ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_BLOCK_NOT_EXISTS.replace("%customblock_name%", blockName));
                                                            return;
                                                        }

                                                        storage.reload(
                                                                blockName,
                                                                () -> ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_RELOAD_BLOCK.replace("%customblock_name%", blockName))
                                                        );
                                                    } else {
                                                        this.plugin.getYamlConfiguration().reload(true);
                                                        this.plugin.getMessagesFile().reload(true);
                                                        this.plugin.getCustomBlockService().getStorage().reloadAll(
                                                                () -> ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_RELOAD)
                                                        );
                                                        this.plugin.initializeConfigValues();
                                                    }
                                                })
                                )
                ).then(
                        new LiteralArgument("erasecbdata")
                                .withPermission(DefaultPermissions.BDC.Command.ERASE_CB_DATA)
                                .withRequirement(Player.class::isInstance)
                                .then(
                                        new LocationArgument("position1", LocationType.PRECISE_POSITION, false)
                                                .then(
                                                        new LocationArgument("position2", LocationType.PRECISE_POSITION, false)
                                                                .executesPlayer((sender, args) -> {
                                                                    Location position1 = (Location) args.get("position1");
                                                                    Location position2 = (Location) args.get("position2");

                                                                    eraseCbData(BoundingBox.of(position1, position2), sender);
                                                                })
                                                )
                                )
                ).then(
                        new LiteralArgument("custom-block")
                                .withRequirement(sender ->
                                        sender.hasPermission(DefaultPermissions.BDC.Command.GIVE_CB)
                                                || sender.hasPermission(DefaultPermissions.BDC.Command.PLACE_CB)
                                                || sender.hasPermission(DefaultPermissions.BDC.Command.BREAK_CB)
                                                || sender.hasPermission(DefaultPermissions.BDC.Command.EDITFILE_CB))
                                .then(
                                        new LiteralArgument("give")
                                                .withPermission(DefaultPermissions.BDC.Command.GIVE_CB)
                                                .then(
                                                        new TextArgument("block")
                                                                .replaceSuggestions(getCustomBlockSuggestions())
                                                                .then(
                                                                        new EntitySelectorArgument.ManyPlayers("receiver")
                                                                                .setOptional(true)
                                                                                .then(
                                                                                        new IntegerArgument("amount", 1, 127)
                                                                                                .setOptional(true)
                                                                                                .executes((sender, args) -> {
                                                                                                    String blockName = (String) args.get("block");
                                                                                                    int amount = (int) args.getOrDefault("amount", 1);

                                                                                                    Collection<Player> receivers = (Collection<Player>) args.get("receiver");

                                                                                                    CustomBlockStorage storage = this.plugin.getCustomBlockService().getStorage();

                                                                                                    if (!storage.containsAbstractCustomBlock(blockName)) {
                                                                                                        ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_BLOCK_NOT_EXISTS.replace("%customblock_name%", blockName));
                                                                                                        return;
                                                                                                    }

                                                                                                    AbstractCustomBlock abstractCustomBlock = storage.getAbstractCustomBlock(blockName);

                                                                                                    ItemStack item = abstractCustomBlock.getItem();
                                                                                                    item.setAmount(amount);

                                                                                                    if (receivers == null) {
                                                                                                        if (sender instanceof Player player) {

                                                                                                            CommandUtil.applyPlaceholdersForItem(item, player);
                                                                                                            CommandUtil.applyPlaceholdersForCommand(abstractCustomBlock, item, player);

                                                                                                            ItemUtil.distributeItem(player, item);
                                                                                                            ChatUtil.sendMessage(player,
                                                                                                                    StringMessagesValue.COMMAND_CUSTOM_BLOCK_GIVE_PLAYER_RECEIVE
                                                                                                                            .replace("%customblock_name%", blockName)
                                                                                                                            .replace("%amount%", String.valueOf(amount))
                                                                                                            );
                                                                                                        } else {
                                                                                                            ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_CUSTOM_BLOCK_GIVE_NO_PLAYER);
                                                                                                        }
                                                                                                    } else {
                                                                                                        for (Player receiver : receivers) {
                                                                                                            CommandUtil.applyPlaceholdersForItem(item, receiver);
                                                                                                            CommandUtil.applyPlaceholdersForCommand(abstractCustomBlock, item, receiver);

                                                                                                            ItemUtil.distributeItem(receiver, item);
                                                                                                            ChatUtil.sendMessage(receiver,
                                                                                                                    StringMessagesValue.COMMAND_CUSTOM_BLOCK_GIVE_PLAYER_RECEIVE
                                                                                                                            .replace("%customblock_name%", blockName)
                                                                                                                            .replace("%amount%", String.valueOf(amount))
                                                                                                            );
                                                                                                        }

                                                                                                        if (receivers.size() == 1) {
                                                                                                            Player receiver = receivers.stream().findFirst().get();
                                                                                                            ChatUtil.sendMessage(sender,
                                                                                                                    StringMessagesValue.COMMAND_CUSTOM_BLOCK_GIVE_PLAYER
                                                                                                                            .replace("%customblock_name%", blockName)
                                                                                                                            .replace("%amount%", String.valueOf(amount))
                                                                                                                            .replace("%player%", receiver.getName())
                                                                                                            );
                                                                                                        } else {
                                                                                                            ChatUtil.sendMessage(sender,
                                                                                                                    StringMessagesValue.COMMAND_CUSTOM_BLOCK_GIVE_PLAYERS
                                                                                                                            .replace("%customblock_name%", blockName)
                                                                                                                            .replace("%amount%", String.valueOf(amount)
                                                                                                                            )
                                                                                                            );
                                                                                                        }
                                                                                                    }

                                                                                                })
                                                                                )
                                                                )
                                                )
                                ).then(
                                        new LiteralArgument("place")
                                                .withPermission(DefaultPermissions.BDC.Command.PLACE_CB)
                                                .then(
                                                        new TextArgument("block")
                                                                .replaceSuggestions(getCustomBlockSuggestions())
                                                                .then(
                                                                        new LocationArgument("location")
                                                                                .then(
                                                                                        new MultiLiteralArgument("attached-face", "north", "south", "east", "west", "up", "down")
                                                                                                .setOptional(true)
                                                                                                .then(
                                                                                                        new IntegerArgument("direction", 0, 360)
                                                                                                                .setOptional(true)
                                                                                                                .then(
                                                                                                                        new ListArgumentBuilder<CustomBlockPlaceOption>("options")
                                                                                                                                .allowDuplicates(false)
                                                                                                                                .withList(CustomBlockPlaceOption.REPLACE_CUSTOM_BLOCK, CustomBlockPlaceOption.LOAD_CHUNK, CustomBlockPlaceOption.BREAK_SOLID_MATERIAL, CustomBlockPlaceOption.SILENT_PLACE)
                                                                                                                                .withStringTooltipMapper(option -> {
                                                                                                                                    String tooltip = switch (option) {
                                                                                                                                        case REPLACE_CUSTOM_BLOCK ->
                                                                                                                                                ChatUtil.color(StringMessagesValue.COMMAND_CUSTOM_BLOCK_PLACE_OPTION_DESCRIPTION_REPLACE_CUSTOM_BLOCK);
                                                                                                                                        case LOAD_CHUNK ->
                                                                                                                                                ChatUtil.color(StringMessagesValue.COMMAND_CUSTOM_BLOCK_PLACE_OPTION_DESCRIPTION_LOAD_CHUNK);
                                                                                                                                        case BREAK_SOLID_MATERIAL ->
                                                                                                                                                ChatUtil.color(StringMessagesValue.COMMAND_CUSTOM_BLOCK_PLACE_OPTION_DESCRIPTION_BREAK_SOLID_MATERIAL);
                                                                                                                                        case SILENT_PLACE ->
                                                                                                                                                ChatUtil.color(StringMessagesValue.COMMAND_CUSTOM_BLOCK_PLACE_OPTION_DESCRIPTION_SILENT_PLACE);
                                                                                                                                    };
                                                                                                                                    return new StringTooltip(option.name().toLowerCase(), Tooltip.messageFromString(tooltip));
                                                                                                                                })
                                                                                                                                .buildGreedy()
                                                                                                                                .setOptional(true)
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    FoliaScheduler.runAtLocation(this.plugin, (Location) args.get("location"), () -> {
                                                                                                                                        String blockName = (String) args.get("block");
                                                                                                                                        Location location = (Location) args.get("location");
                                                                                                                                        LocationPlaceholder locationPlaceholder = new LocationPlaceholder(location);
                                                                                                                                        String attachedFaceStr = (String) args.getOrDefault("attached-face", "up");
                                                                                                                                        int direction = (int) args.getOrDefault("direction", 0);
                                                                                                                                        List<CustomBlockPlaceOption> options = (List<CustomBlockPlaceOption>) args.getOrDefault("options", Collections.emptyList());

                                                                                                                                        BlockFace attachedFace;

                                                                                                                                        CustomBlockStorage storage = this.plugin.getCustomBlockService().getStorage();

                                                                                                                                        if (!storage.containsAbstractCustomBlock(blockName)) {
                                                                                                                                            ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_BLOCK_NOT_EXISTS.replace("%customblock_name%", blockName));
                                                                                                                                            return;
                                                                                                                                        }

                                                                                                                                        try {
                                                                                                                                            attachedFace = BlockFace.valueOf(attachedFaceStr.toUpperCase());
                                                                                                                                        } catch (
                                                                                                                                                IllegalArgumentException e) {
                                                                                                                                            ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_CUSTOM_BLOCK_PLACE_INVALID_ATTACHED_FACE.replace("%face%", attachedFaceStr));
                                                                                                                                            return;
                                                                                                                                        }

                                                                                                                                        AbstractCustomBlock abstractCustomBlock = storage.getAbstractCustomBlock(blockName);

                                                                                                                                        CustomBlockRotation rotation = new BDCCustomBlockRotation(attachedFace, direction);

                                                                                                                                        CustomBlock customBlock;
                                                                                                                                        try {
                                                                                                                                            customBlock = this.plugin.getCustomBlockService().placeBlock(abstractCustomBlock, location, rotation, null, options.toArray(CustomBlockPlaceOption[]::new));
                                                                                                                                        } catch (
                                                                                                                                                IllegalArgumentException e) {
                                                                                                                                            ChatUtil.sendMessage(sender,
                                                                                                                                                    locationPlaceholder.apply(StringMessagesValue.COMMAND_CUSTOM_BLOCK_PLACE_FAILED)
                                                                                                                                                            .replace("%customblock_name%", blockName)
                                                                                                                                                            .replace("%reason%", e.getMessage())
                                                                                                                                            );
                                                                                                                                            return;
                                                                                                                                        }

                                                                                                                                        if (customBlock == null) {
                                                                                                                                            ChatUtil.sendMessage(sender,
                                                                                                                                                    locationPlaceholder.apply(StringMessagesValue.COMMAND_CUSTOM_BLOCK_PLACE_FAILED_WITHOUT_REASON)
                                                                                                                                                            .replace("%customblock_name%", blockName)
                                                                                                                                            );
                                                                                                                                            return;
                                                                                                                                        }

                                                                                                                                        ChatUtil.sendMessage(sender,
                                                                                                                                                locationPlaceholder.apply(StringMessagesValue.COMMAND_CUSTOM_BLOCK_PLACE_PLACED)
                                                                                                                                                        .replace("%customblock_name%", blockName)
                                                                                                                                        );
                                                                                                                                    });
                                                                                                                                })
                                                                                                                )
                                                                                                )
                                                                                )
                                                                )
                                                )
                                ).then(
                                        new LiteralArgument("break")
                                                .withPermission(DefaultPermissions.BDC.Command.BREAK_CB)
                                                .then(
                                                        new LocationArgument("location")
                                                                .replaceSuggestions((info, builder) -> {
                                                                    Player player = (Player) info.sender();

                                                                    RayTraceResult result = player.getWorld().rayTraceEntities(player.getEyeLocation(), player.getLocation().getDirection(), 10, 0.5, entity -> !entity.equals(player));
                                                                    if (result != null && result.getHitEntity() != null) {
                                                                        Entity entity = result.getHitEntity();
                                                                        Location customBlockLocation = CustomBlockKey.holder(entity).getLocation();

                                                                        if (customBlockLocation != null) {
                                                                            builder.suggest((int) customBlockLocation.getX() + " " + (int) customBlockLocation.getY() + " " + (int) customBlockLocation.getZ());
                                                                            return builder.buildFuture();
                                                                        }
                                                                    }

                                                                    Block targetBlockExact = player.getTargetBlockExact(6);
                                                                    Location blockLoc = targetBlockExact != null
                                                                            ? targetBlockExact.getLocation()
                                                                            : null;

                                                                    if (blockLoc != null && blockLoc.getBlock().getType().isSolid()) {
                                                                        builder.suggest((int) blockLoc.getX() + " " + (int) blockLoc.getY() + " " + (int) blockLoc.getZ());
                                                                        return builder.buildFuture();
                                                                    }

                                                                    builder.suggest("~ ~ ~");
                                                                    return builder.buildFuture();
                                                                })
                                                                .then(
                                                                        new ListArgumentBuilder<CustomBlockBreakOption>("options")
                                                                                .allowDuplicates(false)
                                                                                .withList(CustomBlockBreakOption.DROP_ITEM, CustomBlockBreakOption.SILENT_BREAK)
                                                                                .withStringTooltipMapper(option -> {
                                                                                    String tooltip = switch (option) {
                                                                                        case DROP_ITEM ->
                                                                                                ChatUtil.color(StringMessagesValue.COMMAND_CUSTOM_BLOCK_BREAK_OPTION_DESCRIPTION_DROP_ITEM);
                                                                                        case SILENT_BREAK ->
                                                                                                ChatUtil.color(StringMessagesValue.COMMAND_CUSTOM_BLOCK_BREAK_OPTION_DESCRIPTION_SILENT_BREAK);
                                                                                    };
                                                                                    return new StringTooltip(option.name().toLowerCase(), Tooltip.messageFromString(tooltip));
                                                                                })
                                                                                .buildGreedy()
                                                                                .setOptional(true)
                                                                                .executes((sender, args) -> {
                                                                                            FoliaScheduler.runAtLocation(this.plugin, (Location) args.get("location"), () -> {
                                                                                                Location location = (Location) args.get("location");
                                                                                                LocationPlaceholder locationPlaceholder = new LocationPlaceholder(location);
                                                                                                List<CustomBlockBreakOption> options = (List<CustomBlockBreakOption>) args.getOrDefault("options", Collections.emptyList());

                                                                                                CustomBlock customBlock = this.plugin.getCustomBlockService().getCustomBlock(location);

                                                                                                if (customBlock == null) {
                                                                                                    ChatUtil.sendMessage(sender, locationPlaceholder.apply(StringMessagesValue.COMMAND_CUSTOM_BLOCK_BREAK_NO_CUSTOM_BLOCK));
                                                                                                    return;
                                                                                                }

                                                                                                try {
                                                                                                    this.plugin.getCustomBlockService().breakBlock(customBlock, null, options.toArray(CustomBlockBreakOption[]::new));
                                                                                                } catch (IllegalArgumentException e) {
                                                                                                    ChatUtil.sendMessage(sender, "&cFailed to break the block: %s", location, e.getMessage());
                                                                                                    return;
                                                                                                }

                                                                                                ChatUtil.sendMessage(sender, locationPlaceholder.apply(StringMessagesValue.COMMAND_CUSTOM_BLOCK_BREAK_BROKEN)
                                                                                                        .replace("%customblock_name%", customBlock.getName())
                                                                                                );
                                                                                            });
                                                                                        }
                                                                                )
                                                                )
                                                )
                                ).then(
                                        new LiteralArgument("editfile")
                                                .withPermission(DefaultPermissions.BDC.Command.EDITFILE_CB)
                                                .then(
                                                        new TextArgument("block")
                                                                .replaceSuggestions(getCustomBlockSuggestions())
                                                                .then(
                                                                        new LiteralArgument("central-material")
                                                                                .then(
                                                                                        new StringArgument("material")
                                                                                                .replaceSuggestions(ArgumentSuggestions.strings(
                                                                                                                Arrays.stream(Material.values())
                                                                                                                        .filter(Material::isBlock)
                                                                                                                        .map(material -> material.name().toLowerCase())
                                                                                                                        .toList()
                                                                                                        )
                                                                                                ).executes((sender, args) -> {
                                                                                                    String block = (String) args.get("block");
                                                                                                    String material = (String) args.get("material");

                                                                                                    Material actualMaterial = Material.getMaterial(material.toUpperCase());
                                                                                                    if (actualMaterial == null || !actualMaterial.isBlock()) {
                                                                                                        throw CommandAPI.failWithString("Invalid material: " + material);
                                                                                                    }

                                                                                                    setCbConfigValue(block, "central-material", material, sender);
                                                                                                })
                                                                                )
                                                                ).then(
                                                                        new LiteralArgument("sides-count")
                                                                                .then(
                                                                                        new IntegerArgument("count", 1, 360)
                                                                                                .executes((sender, args) -> {
                                                                                                    String block = (String) args.get("block");
                                                                                                    int sidesCount = (int) args.get("count");

                                                                                                    setCbConfigValue(block, "sides-count", sidesCount, sender);
                                                                                                })
                                                                                )
                                                                ).then(
                                                                        new LiteralArgument("save-system")
                                                                                .then(
                                                                                        new StringArgument("save-system-type")
                                                                                                .replaceSuggestions(ArgumentSuggestions.strings("yaml-file", "item"))
                                                                                                .executes((sender, args) -> {
                                                                                                    String block = (String) args.get("block");
                                                                                                    String saveSystemType = (String) args.get("save-system-type");

                                                                                                    if (!saveSystemType.equals("yaml-file") && !saveSystemType.equals("item")) {
                                                                                                        ChatUtil.sendMessage(sender, "&cInvalid save system type: " + saveSystemType);
                                                                                                    }

                                                                                                    setCbConfigValue(block, "save-system", saveSystemType, sender);
                                                                                                })
                                                                                )
                                                                ).then(
                                                                        new LiteralArgument("display")
                                                                                .then(
                                                                                        new MultiLiteralArgument("versioned-command", "spawn-command", "spawn-command-1_19_4", "spawn-command-1_20-1_20_4")
                                                                                                .then(
                                                                                                        new GreedyStringArgument("command")
                                                                                                                .executes((sender, args) -> {
                                                                                                                    String block = (String) args.get("block");
                                                                                                                    String commandType = (String) args.get("versioned-command");
                                                                                                                    String commandLine = (String) args.get("command");
                                                                                                                    Object value = commandLine;

                                                                                                                    if (NumberUtil.isDigitString(commandLine)) {
                                                                                                                        value = NumberUtil.parseNumber(commandLine);
                                                                                                                    }

                                                                                                                    setCbConfigValue(block, "display." + commandType, List.of(value), sender);
                                                                                                                })
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("glowing")
                                                                                                .then(
                                                                                                        new BooleanArgument("glowing-value")
                                                                                                                .executes((sender, args) -> {
                                                                                                                    String block = (String) args.get("block");
                                                                                                                    boolean glowing = (boolean) args.get("glowing-value");

                                                                                                                    setCbConfigValue(block, "display.glowing", glowing, sender);
                                                                                                                })
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("glow-color-override")
                                                                                                .then(
                                                                                                        new StringArgument("color")
                                                                                                                .replaceSuggestions(
                                                                                                                        ArgumentSuggestions.strings(ColorConverter.NAMED_COLORS.keySet().stream().map(String::toLowerCase).toList())
                                                                                                                ).executes((sender, args) -> {

                                                                                                                    String block = (String) args.get("block");
                                                                                                                    String color = (String) args.get("color");

                                                                                                                    setCbConfigValue(block, "display.glow-color-override", color, sender);
                                                                                                                })
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("billboard")
                                                                                                .then(
                                                                                                        new StringArgument("billboard-type")
                                                                                                                .replaceSuggestions(ArgumentSuggestions.strings(
                                                                                                                        "fixed",
                                                                                                                        "horizontal",
                                                                                                                        "vertical",
                                                                                                                        "center"
                                                                                                                )).executes((sender, args) -> {
                                                                                                                    String block = (String) args.get("block");
                                                                                                                    String billboardType = (String) args.get("billboard-type");

                                                                                                                    try {
                                                                                                                        Display.Billboard.valueOf(billboardType.toUpperCase());
                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                        ChatUtil.sendMessage(sender, "&cInvalid billboard type: " + billboardType);
                                                                                                                    }

                                                                                                                    setCbConfigValue(block, "display.billboard", billboardType, sender);
                                                                                                                })

                                                                                                )
                                                                                ).then(
                                                                                        new MultiLiteralArgument("shadow-parameter", "shadow-radius", "shadow-strength")
                                                                                                .then(
                                                                                                        new FloatArgument("value")
                                                                                                                .executes((sender, args) -> {
                                                                                                                    String block = (String) args.get("block");
                                                                                                                    String shadowParameter = (String) args.get("shadow-parameter");
                                                                                                                    float value = (float) args.get("value");

                                                                                                                    setCbConfigValue(block, "display." + shadowParameter, value, sender);
                                                                                                                })
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("view-range")
                                                                                                .then(
                                                                                                        new FloatArgument("range")
                                                                                                                .executes((sender, args) -> {
                                                                                                                    String block = (String) args.get("block");
                                                                                                                    float range = (float) args.get("range");

                                                                                                                    setCbConfigValue(block, "display.view-range", range, sender);
                                                                                                                })
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("use-placeholder")
                                                                                                .then(
                                                                                                        new BooleanArgument("use-placeholder-value")
                                                                                                                .executes((sender, args) -> {
                                                                                                                    String block = (String) args.get("block");
                                                                                                                    boolean usePlaceholder = (boolean) args.get("use-placeholder-value");

                                                                                                                    setCbConfigValue(block, "display.use-placeholder", usePlaceholder, sender);
                                                                                                                })
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("brightness")
                                                                                                .then(
                                                                                                        new MultiLiteralArgument("type", "sky", "block")
                                                                                                                .then(
                                                                                                                        new FloatArgument("level")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String type = (String) args.get("type");
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    float level = (float) args.get("level");

                                                                                                                                    setCbConfigValue(block, "display.brightness." + type, level, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("translation")
                                                                                                .then(
                                                                                                        new MultiLiteralArgument("axis", "x", "y", "z")
                                                                                                                .then(
                                                                                                                        new DoubleArgument("value")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String axis = (String) args.get("axis");
                                                                                                                                    double value = (double) args.get("value");

                                                                                                                                    setCbConfigValue(block, "display.translation." + axis, value, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new MultiLiteralArgument("angle", "yaw", "pitch")
                                                                                                                .then(
                                                                                                                        new FloatArgument("value")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String angle = (String) args.get("angle");
                                                                                                                                    float value = (float) args.get("value");

                                                                                                                                    setCbConfigValue(block, "display.translation." + angle, value, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                )
                                                                                )

                                                                ).then(
                                                                        new LiteralArgument("item")
                                                                                .then(
                                                                                        new LiteralArgument("material")
                                                                                                .then(
                                                                                                        new StringArgument("item-material")
                                                                                                                .replaceSuggestions(ArgumentSuggestions.strings(
                                                                                                                        Arrays.stream(Material.values())
                                                                                                                                .filter(Material::isItem)
                                                                                                                                .map(material -> material.name().toLowerCase())
                                                                                                                                .toList()
                                                                                                                )).executes((sender, args) -> {
                                                                                                                    String block = (String) args.get("block");
                                                                                                                    String material = (String) args.get("item-material");

                                                                                                                    Material actualMaterial = Material.getMaterial(material.toUpperCase());
                                                                                                                    if (actualMaterial == null || !actualMaterial.isItem()) {
                                                                                                                        ChatUtil.sendMessage(sender, "&cInvalid material: " + material);
                                                                                                                    }

                                                                                                                    setCbConfigValue(block, "item.material", material, sender);
                                                                                                                })
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("name")
                                                                                                .then(
                                                                                                        new GreedyStringArgument("item-name")
                                                                                                                .executes((sender, args) -> {
                                                                                                                    String block = (String) args.get("block");
                                                                                                                    String itemName = (String) args.get("item-name");

                                                                                                                    setCbConfigValue(block, "item.name", itemName, sender);
                                                                                                                })
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("item-flags")
                                                                                                .then(
                                                                                                        new ListArgumentBuilder<ItemFlag>("item-flags-list")
                                                                                                                .allowDuplicates(false)
                                                                                                                .withList(List.of(ItemFlag.values()))
                                                                                                                .withMapper(itemFlag -> itemFlag.name().toLowerCase())
                                                                                                                .buildGreedy()
                                                                                                                .executes((sender, args) -> {
                                                                                                                            String block = (String) args.get("block");
                                                                                                                            List<ItemFlag> itemFlags = (List<ItemFlag>) args.get("item-flags-list");

                                                                                                                            setCbConfigValue(block, "item.item-flags", itemFlags, sender);
                                                                                                                        }
                                                                                                                )
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("enchantments")
                                                                                                .then(
                                                                                                        new MapArgumentBuilder<Enchantment, Integer>("enchantments-list", ':')
                                                                                                                .withKeyMapper(enchantment -> Registry.ENCHANTMENT.get(NamespacedKey.minecraft(enchantment.toLowerCase())))
                                                                                                                .withValueMapper(Integer::parseInt)
                                                                                                                .withKeyList(Stream.of(Enchantment.values()).map(enchantment -> enchantment.getKey().getKey().toLowerCase()).toList())
                                                                                                                .withValueList(IntStream.rangeClosed(1, 256).sorted().mapToObj(String::valueOf).toList(), true)
                                                                                                                .build()
                                                                                                                .executes((sender, args) -> {
                                                                                                                            String block = (String) args.get("block");
                                                                                                                            Map<Enchantment, Integer> enchantments = (Map<Enchantment, Integer>) args.get("enchantments-list");

                                                                                                                            setCbConfigValue(block, "item.enchantments", enchantments, sender);
                                                                                                                        }
                                                                                                                )
                                                                                                )

                                                                                ).then(
                                                                                        new LiteralArgument("lore")
                                                                                                .then(
                                                                                                        new GreedyStringArgument("lore-lines")
                                                                                                                .replaceSuggestions((info, builder) -> {
                                                                                                                    builder = builder.createOffset(builder.getStart() + info.currentArg().length());

                                                                                                                    builder.suggest("\"", Tooltip.messageFromString("Opening/closing quote"));

                                                                                                                    return builder.buildFuture();
                                                                                                                })
                                                                                                                .executes((sender, args) -> {
                                                                                                                            String block = (String) args.get("block");
                                                                                                                            String loreLines = (String) args.get("lore-lines");

                                                                                                                            List<String> loreLinesList = parseQuotedStrings(loreLines);

                                                                                                                            setCbConfigValue(block, "item.lore", loreLinesList, sender);
                                                                                                                        }
                                                                                                                )
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("skullmeta")
                                                                                                .then(
                                                                                                        new LiteralArgument("url")
                                                                                                                .then(
                                                                                                                        new StringArgument("value")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String value = (String) args.get("value");

                                                                                                                                    setCbConfigValue(block, "item.skullmeta.url", value, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("name")
                                                                                                                .then(
                                                                                                                        new StringArgument("head-owner-name")
                                                                                                                                .replaceSuggestions((info, builder) -> {
                                                                                                                                    String remaining = builder.getRemainingLowerCase();

                                                                                                                                    Arrays.stream(Bukkit.getOfflinePlayers())
                                                                                                                                            .map(OfflinePlayer::getName)
                                                                                                                                            .filter(Objects::nonNull)
                                                                                                                                            .filter(name -> name.toLowerCase().startsWith(remaining))
                                                                                                                                            .forEach(builder::suggest);

                                                                                                                                    return builder.buildFuture();
                                                                                                                                })
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String headOwnerName = (String) args.get("head-owner-name");

                                                                                                                                    setCbConfigValue(block, "item.skullmeta.name", headOwnerName, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                )
                                                                                )
                                                                ).then(
                                                                        new LiteralArgument("interactions")
                                                                                .then(
                                                                                        new StringArgument("interaction-name")
                                                                                                .replaceSuggestions(getInteractionSuggestions())
                                                                                                .then(
                                                                                                        new MultiLiteralArgument("measurement", "width", "height")
                                                                                                                .then(
                                                                                                                        new FloatArgument("value")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String interactionName = (String) args.get("interaction-name");
                                                                                                                                    String measurement = (String) args.get("measurement");
                                                                                                                                    float value = (float) args.get("value");

                                                                                                                                    setCbConfigValue(block, "interactions." + interactionName + "." + measurement, value, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("command")
                                                                                                                .then(
                                                                                                                        new CommandArgument("command-line")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String interactionName = (String) args.get("interaction-name");
                                                                                                                                    String commandLine = (String) args.get("command-line");

                                                                                                                                    setCbConfigValue(block, "interactions." + interactionName + ".command", List.of(commandLine), sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("command-source")
                                                                                                                .then(
                                                                                                                        new StringArgument("command-source")
                                                                                                                                .replaceSuggestions(ArgumentSuggestions.strings(
                                                                                                                                        "player",
                                                                                                                                        "console"
                                                                                                                                )).executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String interactionName = (String) args.get("interaction-name");
                                                                                                                                    String commandSource = (String) args.get("command-source");

                                                                                                                                    try {
                                                                                                                                        CommandBundle.CommandSource.valueOf(commandSource.toUpperCase());
                                                                                                                                    } catch (
                                                                                                                                            IllegalArgumentException e) {
                                                                                                                                        ChatUtil.sendMessage(sender, "&cInvalid command source: " + commandSource);
                                                                                                                                    }

                                                                                                                                    setCbConfigValue(block, "interactions." + interactionName + ".command-source", commandSource, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("granted-command-permission")
                                                                                                                .then(
                                                                                                                        new ListArgumentBuilder<Permission>("granted-command-permission-list")
                                                                                                                                .allowDuplicates(false)
                                                                                                                                .withList(Bukkit.getPluginManager().getPermissions().stream().toList())
                                                                                                                                .withMapper(Permission::getName)
                                                                                                                                .buildGreedy()
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String interactionName = (String) args.get("interaction-name");
                                                                                                                                    List<Permission> permissions = (List<Permission>) args.get("granted-command-permission-list");

                                                                                                                                    setCbConfigValue(block, "interactions." + interactionName + ".granted-command-permission", permissions, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("offset")
                                                                                                                .then(
                                                                                                                        new MultiLiteralArgument("axis", "x", "y", "z")
                                                                                                                                .then(
                                                                                                                                        new DoubleArgument("value")
                                                                                                                                                .executes((sender, args) -> {
                                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                                    String interactionName = (String) args.get("interaction-name");
                                                                                                                                                    String axis = (String) args.get("axis");
                                                                                                                                                    double value = (double) args.get("value");

                                                                                                                                                    setCbConfigValue(block, "interactions." + interactionName + ".offset." + axis, value, sender);
                                                                                                                                                })
                                                                                                                                )
                                                                                                                )
                                                                                                )
                                                                                )
                                                                ).then(
                                                                        new LiteralArgument("collisions")
                                                                                .then(
                                                                                        new StringArgument("collision-name")
                                                                                                .replaceSuggestions(getCollisionSuggestions())
                                                                                                .then(
                                                                                                        new LiteralArgument("size")
                                                                                                                .then(
                                                                                                                        new DoubleArgument("size-value")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                            String block = (String) args.get("block");
                                                                                                                                            String collisionName = (String) args.get("collision-name");
                                                                                                                                            double sizeValue = (double) args.get("size-value");

                                                                                                                                            setCbConfigValue(block, "collisions." + collisionName + ".size", sizeValue, sender);
                                                                                                                                        }
                                                                                                                                )
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("offset")
                                                                                                                .then(
                                                                                                                        new MultiLiteralArgument("axis", "x", "y", "z")
                                                                                                                                .then(
                                                                                                                                        new DoubleArgument("value")
                                                                                                                                                .executes((sender, args) -> {
                                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                                    String collisionName = (String) args.get("collision-name");
                                                                                                                                                    String axis = (String) args.get("axis");
                                                                                                                                                    double value = (double) args.get("value");

                                                                                                                                                    setCbConfigValue(block, "collisions." + collisionName + ".offset." + axis, value, sender);
                                                                                                                                                })
                                                                                                                                )
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("invisible")
                                                                                                                .then(
                                                                                                                        new BooleanArgument("value")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String collisionName = (String) args.get("collision-name");
                                                                                                                                    boolean value = (boolean) args.get("value");

                                                                                                                                    setCbConfigValue(block, "collisions." + collisionName + ".invisible", value, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("color")
                                                                                                                .then(
                                                                                                                        new StringArgument("color")
                                                                                                                                .replaceSuggestions(ArgumentSuggestions.strings(Arrays.stream(DyeColor.values()).map(color -> color.name().toLowerCase()).toList()))
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String collisionName = (String) args.get("collision-name");
                                                                                                                                    String color = (String) args.get("color");

                                                                                                                                    try {
                                                                                                                                        DyeColor dyeColor = DyeColor.valueOf(color.toUpperCase());
                                                                                                                                        setCbConfigValue(block, "collisions." + collisionName + ".color", dyeColor.name(), sender);
                                                                                                                                    } catch (
                                                                                                                                            IllegalArgumentException e) {
                                                                                                                                        ChatUtil.sendMessage(sender, "&cInvalid color: " + color);
                                                                                                                                    }
                                                                                                                                })

                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("disable-below-1_20_5")
                                                                                                                .then(
                                                                                                                        new BooleanArgument("value")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String collisionName = (String) args.get("collision-name");
                                                                                                                                    boolean value = (boolean) args.get("value");

                                                                                                                                    setCbConfigValue(block, "collisions." + collisionName + ".disable-below-1_20_5", value, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                )
                                                                                )
                                                                ).then(
                                                                        new LiteralArgument("stage-settings")
                                                                                .then(
                                                                                        new LiteralArgument("place")
                                                                                                .then(
                                                                                                        new LiteralArgument("placement-mode")
                                                                                                                .then(
                                                                                                                        new StringArgument("placement-mode")
                                                                                                                                .replaceSuggestions(ArgumentSuggestions.strings(
                                                                                                                                        "default",
                                                                                                                                        "vertical_only",
                                                                                                                                        "horizontal_only",
                                                                                                                                        "vertical_with_horizontal",
                                                                                                                                        "horizontal_with_vertical"
                                                                                                                                ))
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String placementMode = (String) args.get("placement-mode");

                                                                                                                                    try {
                                                                                                                                        CustomBlockPlaceSettings.PlacementMode.valueOf(placementMode.toUpperCase());
                                                                                                                                    } catch (
                                                                                                                                            IllegalArgumentException e) {
                                                                                                                                        ChatUtil.sendMessage(sender, "&cInvalid placement mode: " + placementMode);
                                                                                                                                    }

                                                                                                                                    setCbConfigValue(block, "stage-settings.place.placement-mode", placementMode, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                )
                                                                                                .then(
                                                                                                        new LiteralArgument("command")
                                                                                                                .then(
                                                                                                                        new CommandArgument("command-line")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String commandLine = (String) args.get("command-line");

                                                                                                                                    setCbConfigValue(block, "stage-settings.place.command", commandLine, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("command-source")
                                                                                                                .then(
                                                                                                                        new StringArgument("command-source")
                                                                                                                                .replaceSuggestions(ArgumentSuggestions.strings(
                                                                                                                                        "player",
                                                                                                                                        "console"
                                                                                                                                )).executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String commandSource = (String) args.get("command-source");

                                                                                                                                    try {
                                                                                                                                        CommandBundle.CommandSource.valueOf(commandSource.toUpperCase());
                                                                                                                                    } catch (
                                                                                                                                            IllegalArgumentException e) {
                                                                                                                                        ChatUtil.sendMessage(sender, "&cInvalid command source: " + commandSource);
                                                                                                                                    }

                                                                                                                                    setCbConfigValue(block, "stage-settings.place.command-source", commandSource, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("granted-command-permission")
                                                                                                                .then(
                                                                                                                        new ListArgumentBuilder<Permission>("granted-command-permission-list")
                                                                                                                                .allowDuplicates(false)
                                                                                                                                .withList(Bukkit.getPluginManager().getPermissions().stream().toList())
                                                                                                                                .withMapper(Permission::getName)
                                                                                                                                .buildGreedy()
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                            String block = (String) args.get("block");
                                                                                                                                            List<Permission> permissions = (List<Permission>) args.get("granted-command-permission-list");

                                                                                                                                            setCbConfigValue(block, "stage-settings.place.granted-command-permission", permissions, sender);
                                                                                                                                        }
                                                                                                                                )
                                                                                                                )
                                                                                                )
                                                                                ).then(
                                                                                        new LiteralArgument("break")
                                                                                                .then(
                                                                                                        new LiteralArgument("drop-mode")
                                                                                                                .then(
                                                                                                                        new StringArgument("drop-mode")
                                                                                                                                .replaceSuggestions(ArgumentSuggestions.strings(
                                                                                                                                        "on_ground",
                                                                                                                                        "inventory"
                                                                                                                                ))
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String dropMode = (String) args.get("drop-mode");

                                                                                                                                    try {
                                                                                                                                        CustomBlockBreakSettings.DropMode.valueOf(dropMode.toUpperCase());
                                                                                                                                    } catch (
                                                                                                                                            IllegalArgumentException e) {
                                                                                                                                        ChatUtil.sendMessage(sender, "&cInvalid drop mode: " + dropMode);
                                                                                                                                    }

                                                                                                                                    setCbConfigValue(block, "stage-settings.break.drop-mode", dropMode, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                )
                                                                                                .then(
                                                                                                        new LiteralArgument("command")
                                                                                                                .then(
                                                                                                                        new CommandArgument("command-line")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String commandLine = (String) args.get("command-line");

                                                                                                                                    setCbConfigValue(block, "stage-settings.break.command", commandLine, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("command-source")
                                                                                                                .then(
                                                                                                                        new StringArgument("command-source")
                                                                                                                                .replaceSuggestions(ArgumentSuggestions.strings(
                                                                                                                                        "player",
                                                                                                                                        "console"
                                                                                                                                )).executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String commandSource = (String) args.get("command-source");

                                                                                                                                    try {
                                                                                                                                        CommandBundle.CommandSource.valueOf(commandSource.toUpperCase());
                                                                                                                                    } catch (
                                                                                                                                            IllegalArgumentException e) {
                                                                                                                                        ChatUtil.sendMessage(sender, "&cInvalid command source: " + commandSource);
                                                                                                                                    }

                                                                                                                                    setCbConfigValue(block, "stage-settings.break.command-source", commandSource, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                ).then(
                                                                                                        new LiteralArgument("granted-command-permission")
                                                                                                                .then(
                                                                                                                        new ListArgumentBuilder<Permission>("granted-command-permission-list")
                                                                                                                                .allowDuplicates(false)
                                                                                                                                .withList(Bukkit.getPluginManager().getPermissions().stream().toList())
                                                                                                                                .withMapper(Permission::getName)
                                                                                                                                .buildGreedy()
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                            String block = (String) args.get("block");
                                                                                                                                            List<Permission> permissions = (List<Permission>) args.get("granted-command-permission-list");

                                                                                                                                            setCbConfigValue(block, "stage-settings.break.granted-command-permission", permissions, sender);
                                                                                                                                        }
                                                                                                                                )
                                                                                                                )
                                                                                                )
                                                                                )
                                                                ).then(
                                                                        new LiteralArgument("sound")
                                                                                .then(
                                                                                        new MultiLiteralArgument("stage", "place", "break")
                                                                                                .then(
                                                                                                        new LiteralArgument("sound-type")
                                                                                                                .then(
                                                                                                                        new StringArgument("sound-name")
                                                                                                                                .replaceSuggestions((info, builder) -> {
                                                                                                                                    String remaining = builder.getRemainingLowerCase();

                                                                                                                                    VersionCompat.getSoundNames().forEach(soundName -> {
                                                                                                                                        String soundNameLowerCase = soundName.toLowerCase();

                                                                                                                                        if (soundNameLowerCase.contains(remaining)) {
                                                                                                                                            builder.suggest(soundNameLowerCase);
                                                                                                                                        }
                                                                                                                                    });
                                                                                                                                    return builder.buildFuture();
                                                                                                                                }).executes((sender, args) -> {
                                                                                                                                            String block = (String) args.get("block");
                                                                                                                                            String soundName = (String) args.get("sound-name");

                                                                                                                                            if (!VersionCompat.getSoundNames().contains(soundName.toUpperCase())) {
                                                                                                                                                ChatUtil.sendMessage(sender, "&cInvalid sound type: " + soundName);
                                                                                                                                            }

                                                                                                                                            if (sender instanceof Player player) {
                                                                                                                                                Sound sound = Sound.valueOf(soundName.toUpperCase());

                                                                                                                                                player.playSound(player.getLocation(), sound, 1.0f, 1.0f);
                                                                                                                                            }

                                                                                                                                            setCbConfigValue(block, "sound." + args.get("stage") + ".sound-type", soundName, sender);
                                                                                                                                        }
                                                                                                                                )
                                                                                                                )
                                                                                                ).then(
                                                                                                        new MultiLiteralArgument("sound-parameter", "volume", "pitch")
                                                                                                                .then(
                                                                                                                        new FloatArgument("value")
                                                                                                                                .executes((sender, args) -> {
                                                                                                                                    String block = (String) args.get("block");
                                                                                                                                    String stage = (String) args.get("stage");
                                                                                                                                    String parameter = (String) args.get("sound-parameter");
                                                                                                                                    float value = (float) args.get("value");

                                                                                                                                    setCbConfigValue(block, "sound." + stage + "." + parameter, value, sender);
                                                                                                                                })
                                                                                                                )
                                                                                                )
                                                                                )
                                                                )
                                                )
                                )
                ).then(
                        new LiteralArgument("create")
                                .withPermission(DefaultPermissions.BDC.Command.CREATE_CB)
                                .then(
                                        new TextArgument("id")
                                                .executes((sender, args) -> {
                                                    String id = (String) args.get("id");
                                                    handleCreate(sender, id);
                                                })
                                )
                ).then(
                        new LiteralArgument("spawn")
                                .withPermission(DefaultPermissions.BDC.Command.CREATE_CB)
                                .then(
                                        new TextArgument("id")
                                                .executes((sender, args) -> {
                                                    String id = (String) args.get("id");
                                                    handleCreate(sender, id);
                                                })
                                )
                ).then(
                        new LiteralArgument("animate")
                                .withPermission(DefaultPermissions.BDC.Command.CREATE_CB)
                                .then(
                                        new TextArgument("block")
                                                .replaceSuggestions(getCustomBlockSuggestions())
                                                .then(
                                                        new TextArgument("animation")
                                                                .replaceSuggestions((info, builder) -> {
                                                                    String block = (String) info.previousArgs().getOrDefault("block", "");
                                                                    var anims = it.branduzzo.bBlockDisplays.bdengine.BDEAnimationRegistry.getAllAnimations(block);
                                                                    for (String a : anims.keySet()) builder.suggest(a);
                                                                    if (anims.isEmpty()) builder.suggest("default");
                                                                    return builder.buildFuture();
                                                                })
                                                                .setOptional(true)
                                                                .then(
                                                                        new TextArgument("loop")
                                                                                .replaceSuggestions((info, builder) -> {
                                                                                    builder.suggest("loop");
                                                                                    return builder.buildFuture();
                                                                                })
                                                                                .setOptional(true)
                                                                                .executes((sender, args) -> {
                                                                                    String block = (String) args.get("block");
                                                                                    String anim = (String) args.getOrDefault("animation", "default");
                                                                                    String loopArg = (String) args.getOrDefault("loop", "");
                                                                                    boolean loop = loopArg.equalsIgnoreCase("loop") || loopArg.equalsIgnoreCase("true");
                                                                                    handleAnimate(sender, block, anim, loop);
                                                                                })
                                                                )
                                                )
                                )
                ).then(
                        new LiteralArgument("stop")
                                .withPermission(DefaultPermissions.BDC.Command.CREATE_CB)
                                .then(
                                        new TextArgument("block")
                                                .replaceSuggestions(getCustomBlockSuggestions())
                                                .then(
                                                        new TextArgument("animation")
                                                                .replaceSuggestions((info, builder) -> {
                                                                    String block = (String) info.previousArgs().getOrDefault("block", "");
                                                                    var anims = it.branduzzo.bBlockDisplays.bdengine.BDEAnimationRegistry.getAllAnimations(block);
                                                                    for (String a : anims.keySet()) builder.suggest(a);
                                                                    builder.suggest("default");
                                                                    return builder.buildFuture();
                                                                })
                                                                .setOptional(true)
                                                                .executes((sender, args) -> {
                                                                    String block = (String) args.get("block");
                                                                    String anim = (String) args.getOrDefault("animation", "default");
                                                                    handleStop(sender, block, anim);
                                                                })
                                                )
                                )
                ).then(
                        new LiteralArgument("stopall")
                                .withPermission(DefaultPermissions.BDC.Command.CREATE_CB)
                                .executes((sender, args) -> {
                                    if (!(sender instanceof Player pl)) {
                                        ChatUtil.sendMessage(sender, StringMessagesValue.GENERIC_ONLY_PLAYERS);
                                        return;
                                    }
                                    org.bukkit.Location loc = pl.getTargetBlockExact(10) != null ? pl.getTargetBlockExact(10).getLocation() : pl.getLocation();
                                    var cb = this.plugin.getCustomBlockService().getCustomBlock(loc);
                                    if (cb != null) loc = cb.getLocation();
                                    it.branduzzo.bBlockDisplays.bdengine.BDEAnimationPlayer.stopAll(loc);
                                    ChatUtil.sendMessage(sender, "&aStopped all animations");
                                })
                ).then(
                        new LiteralArgument("sound")
                                .withPermission(DefaultPermissions.BDC.Command.CREATE_CB)
                                .then(
                                        new TextArgument("block")
                                                .replaceSuggestions(getCustomBlockSuggestions())
                                                .then(
                                                        new TextArgument("animation")
                                                                .replaceSuggestions((info, builder) -> {
                                                                    String block = (String) info.previousArgs().getOrDefault("block", "");
                                                                    var anims = it.branduzzo.bBlockDisplays.bdengine.BDEAnimationRegistry.getAllAnimations(block);
                                                                    for (String a : anims.keySet()) builder.suggest(a);
                                                                    builder.suggest("default");
                                                                    return builder.buildFuture();
                                                                })
                                                                .setOptional(true)
                                                                .then(
                                                                        new TextArgument("loop")
                                                                                .replaceSuggestions((info, builder) -> {
                                                                                    builder.suggest("loop");
                                                                                    return builder.buildFuture();
                                                                                })
                                                                                .setOptional(true)
                                                                                .executes((sender, args) -> {
                                                                                    String block = (String) args.get("block");
                                                                                    String anim = (String) args.getOrDefault("animation", "default");
                                                                                    String loopArg = (String) args.getOrDefault("loop", "");
                                                                                    boolean loop = loopArg.equalsIgnoreCase("loop") || loopArg.equalsIgnoreCase("true");
                                                                                    handleSound(sender, block, anim, loop);
                                                                                })
                                                                )
                                                )
                                )
                ).then(
                        new LiteralArgument("playsound")
                                .withPermission(DefaultPermissions.BDC.Command.CREATE_CB)
                                .then(
                                        new TextArgument("block")
                                                .replaceSuggestions(getCustomBlockSuggestions())
                                                .then(
                                                        new TextArgument("animation")
                                                                .replaceSuggestions((info, builder) -> {
                                                                    String block = (String) info.previousArgs().getOrDefault("block", "");
                                                                    var anims = it.branduzzo.bBlockDisplays.bdengine.BDEAnimationRegistry.getAllAnimations(block);
                                                                    for (String a : anims.keySet()) builder.suggest(a);
                                                                    builder.suggest("default");
                                                                    return builder.buildFuture();
                                                                })
                                                                .setOptional(true)
                                                                .executes((sender, args) -> {
                                                                    String block = (String) args.get("block");
                                                                    String anim = (String) args.getOrDefault("animation", "default");
                                                                    handleSound(sender, block, anim, false);
                                                                })
                                                )
                                )
                ).register();
    }

    private void handleCreate(CommandSender sender, String id) {
        if (id == null || id.isBlank()) {
            ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_CREATE_USAGE);
            return;
        }
        String blockName = ServerApiBlockFactory.blockNameForId(id);
        ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_CREATE_FETCHING.replace("%id%", id));
        FoliaScheduler.runAsync(this.plugin, () -> {
            try {
                var model = ServerApiFetcher.fetch(id);
                var file = ServerApiBlockFactory.createBlockFile(this.plugin, blockName, model);
                FoliaScheduler.runGlobal(this.plugin, () -> {
                    this.plugin.getCustomBlockService().getStorage().reloadAll(() -> {
                        ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_CREATE_CREATED.replace("%id%", id).replace("%block%", blockName).replace("%file%", file.getFileName().toString()));
                        if (sender instanceof Player player) {
                            var storage = this.plugin.getCustomBlockService().getStorage();
                            var ab = storage.getAbstractCustomBlock(blockName);
                            if (ab != null) {
                                ItemStack item = ab.getItem();
                                item.setAmount(1);
                                CommandUtil.applyPlaceholdersForItem(item, player);
                                ItemUtil.distributeItem(player, item);
                                ChatUtil.sendMessage(player, StringMessagesValue.COMMAND_CREATE_RECEIVED.replace("%block%", blockName));
                            }
                        }
                    });
                });
            } catch (BDEngineModelNotFoundException e) {
                FoliaScheduler.runGlobal(this.plugin, () -> ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_CREATE_NOT_FOUND.replace("%id%", id).replace("%error%", e.getMessage())));
            } catch (InvalidResponseException e) {
                FoliaScheduler.runGlobal(this.plugin, () -> ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_CREATE_FAILED.replace("%error%", e.getMessage())));
            } catch (Exception e) {
                FoliaScheduler.runGlobal(this.plugin, () -> ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_CREATE_ERROR.replace("%error%", e.getMessage())));
                e.printStackTrace();
            }
        });
    }

    private void handleAnimate(CommandSender sender, String blockName, String animName, boolean loop) {
        if (!(sender instanceof Player player)) {
            ChatUtil.sendMessage(sender, StringMessagesValue.GENERIC_ONLY_PLAYERS);
            return;
        }
        if (!this.plugin.getCustomBlockService().getStorage().containsAbstractCustomBlock(blockName)) {
            ChatUtil.sendMessage(sender, StringMessagesValue.GENERIC_NOT_SPECIFY_BLOCK);
            return;
        }
        var frames = it.branduzzo.bBlockDisplays.bdengine.BDEAnimationRegistry.getAnimation(blockName, animName);
        if (frames == null) {
            ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_ANIMATE_NOT_FOUND.replace("%animation%", animName).replace("%block%", blockName));
            return;
        }
        Location loc = player.getTargetBlockExact(10) != null ? player.getTargetBlockExact(10).getLocation() : player.getLocation();
        var cb = this.plugin.getCustomBlockService().getCustomBlock(loc);
        if (cb == null) loc = player.getLocation();
        else loc = cb.getLocation();
        boolean doLoop = loop || it.branduzzo.bBlockDisplays.bdengine.BDEAnimationRegistry.isLoop(blockName, animName);
        if (doLoop) it.branduzzo.bBlockDisplays.bdengine.BDEAnimationPlayer.play(this.plugin, loc, blockName, animName, true);
        else it.branduzzo.bBlockDisplays.bdengine.BDEAnimationPlayer.play(this.plugin, loc, blockName, animName);
        ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_ANIMATE_PLAYING.replace("%animation%", animName).replace("%block%", blockName).replace("%loop%", doLoop ? StringMessagesValue.COMMAND_ANIMATE_LOOP_SUFFIX : ""));
    }

    private void handleAnimate(CommandSender sender, String blockName, String animName) {
        handleAnimate(sender, blockName, animName, false);
    }

    private void handleStop(CommandSender sender, String blockName, String animName) {
        if (!(sender instanceof Player player)) {
            ChatUtil.sendMessage(sender, StringMessagesValue.GENERIC_ONLY_PLAYERS);
            return;
        }
        Location loc = player.getTargetBlockExact(10) != null ? player.getTargetBlockExact(10).getLocation() : player.getLocation();
        var cb = this.plugin.getCustomBlockService().getCustomBlock(loc);
        if (cb != null) loc = cb.getLocation();
        it.branduzzo.bBlockDisplays.bdengine.BDEAnimationPlayer.stop(loc, blockName, animName);
        ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_ANIMATE_STOPPED.replace("%animation%", animName).replace("%block%", blockName));
    }

    private void handleSound(CommandSender sender, String blockName, String animName, boolean loop) {
        if (!(sender instanceof Player player)) {
            ChatUtil.sendMessage(sender, StringMessagesValue.GENERIC_ONLY_PLAYERS);
            return;
        }
        if (!this.plugin.getCustomBlockService().getStorage().containsAbstractCustomBlock(blockName)) {
            ChatUtil.sendMessage(sender, StringMessagesValue.GENERIC_NOT_SPECIFY_BLOCK);
            return;
        }
        var frames = it.branduzzo.bBlockDisplays.bdengine.BDEAnimationRegistry.getSounds(blockName, animName);
        if (frames == null) frames = it.branduzzo.bBlockDisplays.bdengine.BDEAnimationRegistry.getAnimation(blockName, animName);
        if (frames == null) {
            ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_SOUND_NOT_FOUND.replace("%animation%", animName).replace("%block%", blockName));
            return;
        }
        Location loc = player.getTargetBlockExact(10) != null ? player.getTargetBlockExact(10).getLocation() : player.getLocation();
        var cb = this.plugin.getCustomBlockService().getCustomBlock(loc);
        if (cb == null) loc = player.getLocation();
        else loc = cb.getLocation();
        if (loop) it.branduzzo.bBlockDisplays.bdengine.BDEAnimationPlayer.playSound(this.plugin, loc, blockName, animName, true);
        else it.branduzzo.bBlockDisplays.bdengine.BDEAnimationPlayer.playSound(this.plugin, loc, blockName, animName);
        ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_SOUND_PLAYING.replace("%animation%", animName).replace("%block%", blockName).replace("%loop%", loop ? StringMessagesValue.COMMAND_ANIMATE_LOOP_SUFFIX : ""));
    }

    public ArgumentSuggestions<CommandSender> getCustomBlockSuggestions() {
        return (info, builder) -> {
            String remaining = normalizeRemaining(builder.getRemainingLowerCase());

            for (var tooltip : this.abstractCustomBlockTooltips) {
                String name = tooltip.getAbstractCustomBlock().getName();

                if (name.toLowerCase(Locale.ROOT).contains(remaining)) {
                    String suggestion = tooltip.getSuggestion();

                    if (!isValidStringArgument(suggestion)) {
                        suggestion = "\"" + suggestion + "\"";
                    }

                    builder.suggest(suggestion, tooltip.getTooltip());
                }
            }

            return builder.buildFuture();
        };
    }

    private boolean isValidStringArgument(String input) {
        return input != null && !input.isEmpty() && input.matches("[A-Za-z0-9_+\\-.]+");
    }

    public ArgumentSuggestions<CommandSender> getInteractionSuggestions() {
        return (info, builder) -> {
            CommandArguments commandArguments = info.previousArgs();
            String remaining = builder.getRemainingLowerCase();

            String block = ((String) commandArguments.get("block")).toLowerCase();

            this.interactionSuggestions.forEach((name, suggestions) -> {
                if (block.equals(name.toLowerCase())) {
                    suggestions.forEach(suggestion -> {
                        if (suggestion.toLowerCase().startsWith(remaining)) {
                            builder.suggest(suggestion);
                        }
                    });
                }
            });
            return builder.buildFuture();
        };
    }

    public ArgumentSuggestions<CommandSender> getCollisionSuggestions() {
        return (info, builder) -> {
            CommandArguments commandArguments = info.previousArgs();
            String remaining = builder.getRemainingLowerCase();

            String block = ((String) commandArguments.get("block")).toLowerCase();

            this.collisionSuggestions.forEach((name, suggestions) -> {
                if (block.equals(name.toLowerCase())) {
                    suggestions.forEach(suggestion -> {
                        if (suggestion.toLowerCase().startsWith(remaining)) {
                            builder.suggest(suggestion);
                        }
                    });
                }
            });

            return builder.buildFuture();
        };
    }

    private void setCbConfigValue(String blockName, String path, Object value, CommandSender sender) {
        CustomBlockStorage storage = this.plugin.getCustomBlockService().getStorage();

        if (!(storage instanceof BDCCustomBlockConfigStorage configStorage)) {
            return;
        }

        CustomBlockConfigurationFile file = configStorage.getCustomBlockRepository().getFile(blockName);

        if (file == null) {
            ChatUtil.sendMessage(sender, StringMessagesValue.COMMAND_BLOCK_NOT_EXISTS.replace("%customblock_name%", blockName));
            return;
        }

        String valueName = value.toString();

        if (path.endsWith("enchantments")) {
            try {
                Map<Enchantment, Integer> enchantments = (Map<Enchantment, Integer>) value;

                value = PersistentDataTypes.ENCHANT.toPrimitive(enchantments, null);

                valueName = enchantments.entrySet().stream()
                        .map(entry -> entry.getKey().getKey().getKey() + ":" + entry.getValue())
                        .collect(Collectors.joining(", "));
            } catch (ClassCastException ignore) {
            }
        }

        if (value instanceof List<?> list) {

            value = list.stream().map(o -> {
                if (o instanceof Permission permission) {
                    return permission.getName();
                } else if (o instanceof ItemFlag itemFlag) {
                    return itemFlag.name();
                }
                return o.toString();
            }).toList();

            valueName = "\n" + list.stream().map(o -> {
                if (o instanceof Permission permission) {
                    return permission.getName();
                }
                return o.toString();
            }).collect(Collectors.joining("\n")) + "\n";
        }

        file.set(path, value);
        ChatUtil.sendMessage(
                sender,
                StringMessagesValue.COMMAND_CUSTOM_BLOCK_EDITFILE_SET
                        .replace("%customblock_name%", blockName)
                        .replace("%parameter%", path)
                        .replace("%value%", valueName)
        );
    }

    public void reloadSuggestions() {
        abstractCustomBlockTooltips.clear();
        interactionSuggestions.clear();
        List<AbstractCustomBlock> abstractCustomBlocks = this.plugin.getCustomBlockService().getStorage().getAbstractCustomBlocks();

        for (AbstractCustomBlock abstractCustomBlock : abstractCustomBlocks) {

            AbstractCustomBlockTooltip abstractCustomBlockTooltip = new AbstractCustomBlockTooltip(abstractCustomBlock);

            abstractCustomBlockTooltips.add(abstractCustomBlockTooltip);


            List<ConfiguredInteraction> interactions = abstractCustomBlock.getConfiguredInteractions();
            List<ConfiguredCollision> collisions = abstractCustomBlock.getConfiguredCollisions();

            if (!interactions.isEmpty()) {
                interactionSuggestions.put(abstractCustomBlock.getName(), interactions.stream().map(ConfiguredEntity::getIdentifier).toList());
            }

            if (!collisions.isEmpty()) {
                collisionSuggestions.put(abstractCustomBlock.getName(), collisions.stream().map(ConfiguredEntity::getIdentifier).toList());
            }
        }
    }


    private void eraseCbData(BoundingBox boundingBox, Player sender) {
        WorldSelection worldSelection = new WorldSelection(boundingBox, sender.getWorld());

        List<Entity> displayEntities = new ArrayList<>();
        List<Entity> interactions = new ArrayList<>();
        List<Entity> collisions = new ArrayList<>();


        sender.getWorld().getNearbyEntities(
                boundingBox,
                entity -> entity instanceof Display || entity instanceof Interaction || entity instanceof Shulker
        ).forEach(entity -> {
            if (entity instanceof Display) {
                displayEntities.add(entity);
            } else if (entity instanceof Interaction) {
                interactions.add(entity);
            } else if (entity instanceof Shulker) {
                collisions.add(entity);
            }
        });


        final int[] blocksCount = {0};

        worldSelection.getLocations().forEach(location -> {
                    CustomBlockData customBlockData = new CustomBlockData(location.getBlock(), BlockDisplayCreator.getInstance());

                    if (customBlockData.has(CustomBlockKey.NAME)) {
                        customBlockData.remove(CustomBlockKey.NAME);
                        customBlockData.remove(CustomBlockKey.SERVICE_CLASS);
                        customBlockData.remove(CustomBlockKey.LOCATION);
                        customBlockData.remove(CustomBlockKey.CUSTOM_BLOCK_UUID);
                        customBlockData.remove(CustomBlockKey.DISPLAY_UUID);
                        customBlockData.remove(CustomBlockKey.INTERACTION_UUID);
                        customBlockData.remove(CustomBlockKey.COLLISION_UUID);
                        customBlockData.remove(CustomBlockKey.INTERACTION_IDENTIFIER);
                        customBlockData.remove(CustomBlockKey.COLLISION_IDENTIFIER);
                        customBlockData.remove(CustomBlockKey.BLOCK_ROTATION);
                        customBlockData.remove(CustomBlockKey.ITEM);
                        customBlockData.remove(CustomBlockKey.DISPLAY_SPAWN_COMMAND);
                        blocksCount[0]++;
                    }
                }
        );

        displayEntities.forEach(Entity::remove);
        interactions.forEach(Entity::remove);
        collisions.forEach(Entity::remove);

        ChatUtil.sendMessage(sender, "&6Killed %d display entities", displayEntities.size());
        ChatUtil.sendMessage(sender, "&6Killed %d interaction entities", interactions.size());
        ChatUtil.sendMessage(sender, "&6Killed %d collision entities", collisions.size());
        ChatUtil.sendMessage(sender, "&6Cleared %d custom blocks", blocksCount[0]);
    }

    private static String normalizeRemaining(String remaining) {
        if (remaining == null || remaining.isEmpty()) {
            return "";
        }

        if (remaining.startsWith("\"")) {
            remaining = remaining.substring(1);
        }

        if (remaining.endsWith("\"") && remaining.length() > 1) {
            remaining = remaining.substring(0, remaining.length() - 1);
        }

        return remaining;
    }

    public static List<String> parseQuotedStrings(String input) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();

        boolean inQuotes = false;
        boolean escapeNext = false;

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            if (escapeNext) {
                current.append(c);
                escapeNext = false;
            } else if (c == '\\') {
                escapeNext = true;
            } else if (c == '"') {
                if (inQuotes) {
                    result.add(current.toString());
                    current.setLength(0);
                    inQuotes = false;
                } else {
                    inQuotes = true;
                }
            } else {
                if (inQuotes) {
                    current.append(c);
                } else if (!Character.isWhitespace(c)) {
                    throw new IllegalArgumentException("Unexpected character outside quotes at position " + i + ": " + c);
                }
            }
        }

        if (inQuotes) {
            throw new IllegalArgumentException("Unclosed quote in input.");
        }

        return result;
    }
}
