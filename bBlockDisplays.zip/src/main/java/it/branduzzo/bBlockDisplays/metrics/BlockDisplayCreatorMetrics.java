package it.branduzzo.bBlockDisplays.metrics;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import it.branduzzo.bBlockDisplays.BlockDisplayCreator;
import it.branduzzo.bBlockDisplays.compat.HorizonSupport;
import it.branduzzo.bBlockDisplays.util.FoliaScheduler;
import org.bstats.bukkit.Metrics;
import org.bstats.charts.DrilldownPie;
import org.bstats.charts.SimplePie;
import org.bstats.charts.SingleLineChart;

/**
 * Implementation of {@link PluginMetrics} for bBlockDisplays.
 * <p>
 * Wraps the bStats {@link Metrics} system and registers custom charts
 * to monitor plugin-specific statistics, such as the number of custom blocks.
 * </p>
 */
@Getter
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class BlockDisplayCreatorMetrics implements PluginMetrics {
    /**
     * The main plugin instance.
     */
    BlockDisplayCreator plugin;
    /**
     * The unique plugin identifier used for metrics reporting.
     */
    int pluginId;
    /**
     * The bStats metrics handler.
     */
    Metrics metrics;

    /**
     * Creates a new metrics handler for bBlockDisplays.
     *
     * @param plugin   the plugin instance
     * @param pluginId the unique plugin ID
     */
    public BlockDisplayCreatorMetrics(BlockDisplayCreator plugin, int pluginId) {
        this.plugin = plugin;
        this.pluginId = pluginId;
        this.metrics = new Metrics(plugin, pluginId);

        registerCustomBlocksChart();
        registerServerTypeChart();
        registerFoliaChart();
    }

    private void registerCustomBlocksChart() {
        this.metrics.addCustomChart(new SingleLineChart(
                "customBlocks",
                () -> this.plugin.getCustomBlockService().getStorage().getAbstractCustomBlocks().size()
        ));
    }

    private void registerServerTypeChart() {
        this.metrics.addCustomChart(new SimplePie("server_type", () -> {
            if (HorizonSupport.isHorizon()) return "Horizon";
            if (FoliaScheduler.isFolia()) return "Folia";
            return "Paper/Spigot";
        }));
    }

    private void registerFoliaChart() {
        this.metrics.addCustomChart(new DrilldownPie("blocks_per_server", () -> {
            java.util.Map<String, java.util.Map<String, Integer>> map = new java.util.HashMap<>();
            String type = HorizonSupport.isHorizon() ? "Horizon" : FoliaScheduler.isFolia() ? "Folia" : "Paper";
            java.util.Map<String, Integer> inner = new java.util.HashMap<>();
            inner.put("blocks", this.plugin.getCustomBlockService().getStorage().getAbstractCustomBlocks().size());
            map.put(type, inner);
            return map;
        }));
    }
}

