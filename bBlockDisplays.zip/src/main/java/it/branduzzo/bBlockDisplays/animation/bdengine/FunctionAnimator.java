package it.branduzzo.bBlockDisplays.animation.bdengine;

import it.branduzzo.bBlockDisplays.file.mcfunction.MCFunction;

public interface FunctionAnimator {
    MCFunction getPlayFunction();

    MCFunction getPlayLoopFunction();
}
