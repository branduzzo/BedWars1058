package it.branduzzo.bBlockDisplays.animation.bdengine;

import it.branduzzo.bBlockDisplays.file.mcfunction.MCFunction;

import java.util.List;

public interface FunctionAnimation {
    List<MCFunction> getFunctions();
}
