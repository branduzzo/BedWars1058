package it.branduzzo.bBlockDisplays.file.config.loader;

import it.branduzzo.bBlockDisplays.custom.block.AbstractCustomBlock;

public interface CustomBlockConfigurationFile {
    AbstractCustomBlock getAbstractCustomBlock();

    void set(String key, Object value);

    Object get(String key);

    String getName();

    String getPath();

    void reload();
}
