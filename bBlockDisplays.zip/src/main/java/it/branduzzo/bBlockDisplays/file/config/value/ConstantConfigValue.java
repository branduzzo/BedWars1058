package it.branduzzo.bBlockDisplays.file.config.value;

import it.branduzzo.bBlockDisplays.data.yaml.YamlData;

public interface ConstantConfigValue<T> {
    void initialize(YamlData<T> configuration);
}
