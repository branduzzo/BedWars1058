package it.branduzzo.bBlockDisplays.entity.display;

import it.branduzzo.bBlockDisplays.rotation.DirectedVector;

public interface TranslationVectorAdjustable {
    DirectedVector getTranslation();

    void setTranslation(DirectedVector translation);
}
