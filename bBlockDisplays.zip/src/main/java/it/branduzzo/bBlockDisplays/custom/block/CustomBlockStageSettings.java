package it.branduzzo.bBlockDisplays.custom.block;

public interface CustomBlockStageSettings {
    CustomBlockPlaceSettings getPlaceSettings();

    CustomBlockBreakSettings getBreakSettings();
}
