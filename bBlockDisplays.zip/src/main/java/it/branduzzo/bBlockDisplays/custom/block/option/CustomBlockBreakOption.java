package it.branduzzo.bBlockDisplays.custom.block.option;

public enum CustomBlockBreakOption implements CustomBlockOption {
    DROP_ITEM,
    SILENT_BREAK
}
