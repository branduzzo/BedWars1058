package it.branduzzo.bBlockDisplays.custom.block;

import it.branduzzo.bBlockDisplays.sound.PlayableSound;
import org.jetbrains.annotations.Nullable;


public interface CustomBlockSoundGroup {
    @Nullable
    PlayableSound getPlaceSound();

    void setPlaceSound(PlayableSound sound);

    @Nullable
    PlayableSound getBreakSound();

    void setBreakSound(PlayableSound sound);
}
