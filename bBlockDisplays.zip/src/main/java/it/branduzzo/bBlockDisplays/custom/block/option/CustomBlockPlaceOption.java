package it.branduzzo.bBlockDisplays.custom.block.option;

public enum CustomBlockPlaceOption implements CustomBlockOption {
    REPLACE_CUSTOM_BLOCK,
    BREAK_SOLID_MATERIAL,
    SILENT_PLACE,
    LOAD_CHUNK
}
