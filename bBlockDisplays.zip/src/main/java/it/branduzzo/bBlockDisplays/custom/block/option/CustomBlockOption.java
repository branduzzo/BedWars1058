package it.branduzzo.bBlockDisplays.custom.block.option;

import it.branduzzo.bBlockDisplays.annotation.OptionInterface;

@OptionInterface
public interface CustomBlockOption {
}
