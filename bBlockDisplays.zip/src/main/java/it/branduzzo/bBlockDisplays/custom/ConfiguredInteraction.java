package it.branduzzo.bBlockDisplays.custom;

import it.branduzzo.bBlockDisplays.common.DeepCloneable;
import org.bukkit.entity.Interaction;
import org.jetbrains.annotations.Nullable;

public interface ConfiguredInteraction extends ConfiguredEntity<Interaction>, DeepCloneable<ConfiguredInteraction> {
    @Nullable
    InteractionHandler getInteractionHandler();

    void setInteractionHandler(InteractionHandler interactionHandler);
}
