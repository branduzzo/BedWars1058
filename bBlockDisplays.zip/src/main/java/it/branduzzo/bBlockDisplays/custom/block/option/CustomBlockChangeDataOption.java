package it.branduzzo.bBlockDisplays.custom.block.option;

public enum CustomBlockChangeDataOption implements CustomBlockOption {
    SAVE_TO_STORAGE
}
