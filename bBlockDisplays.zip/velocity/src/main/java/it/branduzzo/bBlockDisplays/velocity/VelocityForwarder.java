package it.branduzzo.bBlockDisplays.velocity;

import com.google.inject.Inject;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.messages.ChannelIdentifier;
import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import org.slf4j.Logger;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;

@Plugin(id = "bblockdisplays-velocity", name = "bBlockDisplays-Velocity", version = "1.0.0", description = "Forwarder for bBlockDisplays proxy commands", authors = {"Branduzzo"})
public class VelocityForwarder {
    private final ProxyServer server;
    private final Logger logger;
    private final ChannelIdentifier bungee = MinecraftChannelIdentifier.create("bungeecord", "main");
    private final ChannelIdentifier velocityMain = MinecraftChannelIdentifier.create("velocity", "main");
    private final ChannelIdentifier velocityCmd = MinecraftChannelIdentifier.create("velocity", "player_command");
    private final ChannelIdentifier bbd = MinecraftChannelIdentifier.create("bblockdisplays", "proxy");

    @Inject
    public VelocityForwarder(ProxyServer server, Logger logger) {
        this.server = server;
        this.logger = logger;
    }

    @Subscribe
    public void onInit(ProxyInitializeEvent e) {
        server.getChannelRegistrar().register(bungee, velocityMain, velocityCmd, bbd);
        logger.info("bBlockDisplays Velocity forwarder ready");
    }

    @Subscribe
    public void onPluginMessage(PluginMessageEvent ev) {
        if (!ev.getIdentifier().equals(bungee) && !ev.getIdentifier().equals(velocityMain) && !ev.getIdentifier().equals(velocityCmd) && !ev.getIdentifier().equals(bbd)) return;
        ev.setResult(PluginMessageEvent.ForwardResult.handled());
        try {
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(ev.getData()));
            if (ev.getIdentifier().equals(bbd)) {
                String uuid = in.readUTF();
                String cmd = in.readUTF();
                logger.info("bblockdisplays:proxy -> Executing '{}' for {}", cmd, uuid);
                server.getPlayer(java.util.UUID.fromString(uuid)).ifPresent(p -> server.getCommandManager().executeAsync(p, cmd));
                return;
            }
            if (ev.getIdentifier().equals(bungee)) {
                String sub = in.readUTF();
                if (sub.equals("Forward")) {
                    String target = in.readUTF();
                    String channel = in.readUTF();
                    if (channel.equals("VelocityCommand") || channel.equals("queue")) {
                        short len = in.readShort();
                        byte[] data = new byte[len];
                        in.readFully(data);
                        DataInputStream msg = new DataInputStream(new ByteArrayInputStream(data));
                        String uuid = msg.readUTF();
                        String cmd = msg.readUTF();
                        server.getPlayer(java.util.UUID.fromString(uuid)).ifPresent(p -> {
                            logger.info("Executing proxy command '{}' for {}", cmd, p.getUsername());
                            server.getCommandManager().executeAsync(p, cmd);
                        });
                    }
                }
            } else {
                String cmd = in.readUTF();
                if (ev.getSource() instanceof Player p) {
                    logger.info("Executing proxy command '{}' for {}", cmd, p.getUsername());
                    server.getCommandManager().executeAsync(p, cmd);
                } else if (ev.getSource() instanceof com.velocitypowered.api.proxy.server.RegisteredServer) {
                    String s = cmd;
                    server.getAllPlayers().stream().findFirst().ifPresent(pl -> {
                        logger.info("Executing proxy command '{}' for {}", s, pl.getUsername());
                        server.getCommandManager().executeAsync(pl, s);
                    });
                }
            }
        } catch (Exception ex) {
            logger.warn("Proxy command forward failed", ex);
        }
    }
}
